function loadIndex(){ //UTILITZADA DESDE index.php PER CARREGAR index.php EN EL DIV GENERAL id="index"

    var xmlhttp;
    if (window.XMLHttpRequest) {
        // code for modern browsers
        xmlhttp = new XMLHttpRequest();
    } else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("index").innerHTML = xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET", "index.php", true);
    xmlhttp.send();
}

function ajaxget(folder, page){ //CARREGA UNA PAGINA AMB AJAX AL DIV id="ajax"

    var xmlhttp;
    if (window.XMLHttpRequest) {
        // code for modern browsers
        xmlhttp = new XMLHttpRequest();
    } else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("ajax").innerHTML = xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET", folder + "/" + page + ".php", true);
    xmlhttp.send();
}

function getParamNom(folder, page, nom_marca){ //CARREGA UNA PAGINA AMB AJAX AMB UN PARÁMETRE  ?nom=" X " A LA URL (utilitzada a categories.php cap a models.php)
    var xmlhttp;
    if (window.XMLHttpRequest) {
        // code for modern browsers
        xmlhttp = new XMLHttpRequest();
    } else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("ajax").innerHTML = xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET", folder + "/" + page + ".php?nom=" + nom_marca, true);
    xmlhttp.send();
}

function getParamId(folder, page, id){ //FUNCIO QUE CARREGA UNA PAGINA AMB AJAX AMB UN PARÀMETRE ?id=" X " A LA URL (utilitzada a categories.php)

    var xmlhttp;
    if (window.XMLHttpRequest) {
        // code for modern browsers
        xmlhttp = new XMLHttpRequest();
    } else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("ajax").innerHTML = xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET", folder + "/" + page + ".php?id=" + id, true);
    xmlhttp.send();
}

function eliminaCarrito(folder, page, id){

    var xmlhttp;
    if (window.XMLHttpRequest) {
        // code for modern browsers
        xmlhttp = new XMLHttpRequest();
    } else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("ajax").innerHTML = xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET", folder + "/" + page + ".php?id=" + id, true);
    xmlhttp.send();
}

function getParamQuantitat(folder, page, total){
    var xmlhttp;
    if (window.XMLHttpRequest) {
        // code for modern browsers
        xmlhttp = new XMLHttpRequest();
    } else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("ajax").innerHTML = xmlhttp.responseText;
        }
    };
    xmlhttp.open("GET", folder + "/" + page + ".php?quantitat=" + total, true);
    xmlhttp.send();
}

















