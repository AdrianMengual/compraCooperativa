<!DOCTYPE html>
<html>
<head>
	<title> Guitars.com </title>
	<meta charset="UTF-8"/>
	<link rel="stylesheet" href="CSS/styles.css" type="text/css">
	<script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="JS/index.js"></script>
</head>

<body>
<div id="index">
	<section>
		<nav id="menuIndex"> <!--menu amb les 3 opcions-->
			<ul>
				<li>
					<a href="#" onclick="loadIndex()"><img id="fotoLogoPag" src="IMG/logoPag.jpg" alt="guitars.com logo"/></a>
				</li>
				<li>
					<a href="#" onclick="ajaxget('view', 'categories')">Productes</a>
				</li>
				<li>
					<a href="#" onclick="ajaxget('view', 'info')">Sobre nosaltres</a>
				</li>
				<li>
					<a href="#" onclick="ajaxget('view', 'login')">Admins</a>
				</li>
				<li>
					<a href="#" onclick="ajaxget('view', 'carrito')"><img id="fotoCarro" src="IMG/carret.png" alt="carro logo"/> </a>
				</li>
			</ul>
		</nav>
	</section>

	<div id="ajax">

		<header>
			<h1>Guitars.com: La teva tenda de guitarres</h1>
			<h3> Benvingut! </h3>
			<p>A <b>Guitars.com</b> trobarà tot tipus de guitarres. Les marques més <b>prestigioses</b>, alternatives
				<b>econòmiques</b> y serveis <b>gratuits</b> per músics. <br> Enviem a ports pagats a Espanya península
				en compres de més de <b>199€</b>
				(amb excepció de Canàries, Balears, Ceuta y Melilla on aquestes condicions poden variar.<br/>
				Tots els preus inclouen el 21% de IVA i amb 3 anys de garantía.</p>
		</header>
		<hr>
		<section>
			<br>
			<section>
				<div id="portada1"> <!--capçalera amb imatges de algunes de les guitarres amb ofertes-->
						<img src="IMG/Epiphone/Casino/1.jpg" alt="guitarra1"/>
						<img src="IMG/Gibson/SG/1.jpg" alt="guitarra2"/>
						<img src="IMG/Fender/Telecaster/1.jpg" alt="guitarra3"/>
						<img src="IMG/Fender/Jaguar/1.jpg" alt="guitarra4"/>
				</div>
			</section>
			<br>
			<hr>
			<br>
			<section>
				<div id="portada2"> <!--capçalera amb imatges de algunes de les guitarres que més agraden als usuaris-->
					<img src="IMG/Fender/Stratocaster/1.jpg" alt="guitarra5"/>
					<img src="IMG/Epiphone/Explorer/1.jpg" alt="guitarra6"/>
					<img src="IMG/Ibanez/JEM77P/1.jpg" alt="guitarra7"/>
					<img src="IMG/Ibanez/AF75/1.jpg" alt="guitarra8"/>
				</div>
			</section>
		</section>
		<br/>

	</div>
	<div id="end">
		<hr/>
		<section>
			<footer>
				<p>© 1998 - 2016</p>
			</footer>
			<a href="#" onclick="ajaxget('view', 'info')">Sobre nosaltres</a>
		</section>
	</div>
</div>
</body>
</html>
