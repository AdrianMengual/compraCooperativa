<?php 

	function connectDB(){
		$servername = "localhost";
		$username = "root";
		$password = ""; //modificar por "avergara334" en el servidor del proyecto
		$dbname = "compracooperativa"; //modificar por "pruebalis" en el servidor del proyecto

		//Creamos la conexion
		$conn = new mysqli($servername, $username, $password, $dbname);

			if ($conn->connect_error) {
				die("Conexion fallida: " . $conn->connect_error);
			}
		$conn ->set_charset("utf8");
		return $conn;
 	}

 	function result_productos(){
        $conn = connectDB(); 
        $sql_productos = "SELECT ID_producto, ID_categoria, nombre, descripcion, tamano, stock, imagen, precio FROM `Productos`";
        $result_productos = $conn->query($sql_productos);

        return $result_productos;   
    }
?>