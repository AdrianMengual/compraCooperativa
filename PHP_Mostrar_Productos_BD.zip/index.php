﻿<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">
</head>
<body>

<!--Añadido albertvelez-->
<?php
	require("BD.php");

	$result_productos = result_productos();

	$productos = array();

	while($row = $result_productos->fetch_assoc()) {
		$productos[]= $row;
    }
?>
<!--oooooooooooooooooooo-->


<h2 class="text-left">sample center heading</h2>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Compra Cooperativa</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="#" data-toggle="modal" data-target="#login-modal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>


<a href="#" data-toggle="modal" data-target="#login-modal">Login</a>


<div class="container">
 
  <div class="row">

  	
<!--Añadido albertvelez-->
    <?php
      foreach($productos as $productos){ 
    ?>
    <div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/<?php echo $productos['imagen'];?>" alt="">
							<div class="caption">
								<h4><?php echo $productos['nombre'];?></h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro <?php echo $productos['precio'];?></p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      
    </div>
    <?php
      }              
    ?>
<!--oooooooooooooooooooo-->


<!--	<div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div>
	<div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
  aria-valuemin="0" aria-valuemax="100" style="width:50%">
    50% Complete (info)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60"
  aria-valuemin="0" aria-valuemax="100" style="width:60%">
    60% Complete (warning)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div><div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/prueba.gif" alt="">
							<div class="caption">
								<h4>Nombre del producto</h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro 100,00</p>
								<div class="progress">
  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:70%">
    70% Complete (danger)
  </div>
</div>
								<a class="btn btn-primary" href="#">View</a>
								<a class="btn btn-success" href="#">Add to Cart</a>
							</div>
						</div>
      <p>Lorem ipsum...</p>
    </div>-->
	
	
	
  </div>
</div>
<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% Complete (success)
  </div>
</div>

<div class="progress">
  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
  aria-valuemin="0" aria-valuemax="100" style="width:50%">
    50% Complete (info)
  </div>
</div>

<div class="progress">
  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60"
  aria-valuemin="0" aria-valuemax="100" style="width:60%">
    60% Complete (warning)
  </div>
</div>

<div class="progress">
  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70"
  aria-valuemin="0" aria-valuemax="100" style="width:70%">
    70% Complete (danger)
  </div>
</div>



<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Login to Your Account</h1><br>
				  <form>
					<input type="text" name="user" placeholder="Username">
					<input type="password" name="pass" placeholder="Password">
					<input type="submit" name="login" class="login loginmodal-submit" value="Login">
				  </form>
					
				  <div class="login-help">
					<a href="#">Register</a> - <a href="#">Forgot Password</a>
				  </div>
				</div>
			</div>


</body>
</html>
