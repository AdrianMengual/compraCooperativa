	<?php 
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
        "http://www.w3.org/TR/html4/strict.dtd">
<html lang="ca"> <!-- Idioma català -->
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-8">

		<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,300|Roboto:400,300,300italic,400italic,500|Roboto+Condensed:400,400italic|Montserrat:400,700|Roboto+Slab:400,300|Work+Sans:400,300|Khula:400,300|Hind+Siliguri:500,400|Lato:400,300,700|Didact+Gothic| Slabo+27px|Amatic+SC|Alegreya|Old+Standard+TT|Noticia+Text|Sanchez' rel='stylesheet' type='text/css'><!-- Fonts
		importades. -->
		<title>DSAK CLOTHING</title>  <!-- Nom que apareix a la pàgina de navegació. -->
		<!--
	
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
		<script src="ajax.js" type="text/javascript"></script>
		<script src="comprobacions.js" type="text/javascript"></script> Para poder llamar las funciones del script.-->
		
		

		
	</head>
	<body>
		
					<?php 
					//$con= mysql_connect("localhost", "root", "");
					$con = mysqli_connect("localhost", "root", "avergara334","CompraCooperativa");

					//$enlace = mysql_connect('localhost', 'root', '');
					if (!$con) {
						die('No se pudo conectar : ' . mysql_error());
					}else{
						
						echo "conectadoos";
					}
					$sql="SELECT * FROM algoritmos ;";
					$result=mysqli_query($con,$sql);
					while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
							//$_SESSION['nom']=$row['Nombre'];
							//echo $row['variables'];
							//echo $row['funcion'];
							
							$nuevafunc1 = create_function($row['variables'],$row['funcion']);
							echo $nuevafunc1(2);
							echo $nuevafunc1(3);
							echo $nuevafunc1(4);
						}
						

					// Hacer que foo sea la base de datos actual
					//$bd_seleccionada = mysql_select_db('pruebalis', $enlace);
					//if (!$bd_seleccionada) {
					//	die ('No se puede usar pruebalis : ' . mysql_error());
					//}
					/*

					$con=mysqli_connect("localhost", "tdiw-h5", "tdiw-h5-S8", "tdiw-h5");

					if (mysqli_connect_errno())
					  {
					  echo "Failed to connect to MySQL: " . mysqli_connect_error();
					  }
					   
						$sql="SELECT * FROM usuario WHERE E_mail='".$usuari."' AND Password='".$pass."';";
						$sql1="SELECT * FROM administrador WHERE E_mail='".$usuari."' AND Password='".$pass."';";

						$result=mysqli_query($con,$sql);

						$result1=mysqli_query($con,$sql1);

					while($row=mysqli_fetch_array($result1,MYSQLI_ASSOC)) {
							$_SESSION['nom']=$row['Nombre'];
							$_SESSION['admin']=$row['Id_Administrador'];
						}


					if(!isset($_SESSION['admin'])){
						while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)) {
							$_SESSION['nom']=$row['Nombre'];
						}


					}
					
					
					*/
					
					
					
					
					
					
					function recursividad($a)
					{
						
						if ($a < 20) {
							echo "$a\n";
							
							
						}
						return $a*$a;
					}
					
					
					


?>


					<?php
                    echo "HOLA AMIGOS";
					//INSERT INTO `pruebalis`.`algoritmos` (`Company`, `name`, `variables`, `funcion`) VALUES ('compan', 'nombre', '$a', 'if ($a < 20) {
					//		echo "$a\\n";
					//		recursividad($a + 1);
					//	}');
					/*
					$nuevafunc = create_function('$a,$b', 'return "ln($a) + ln($b) = " . log($a * $b);');
					echo "Nueva función anónima: $nuevafunc\n";
					echo $nuevafunc(2, M_E) . "\n";
					*/
					// imprime
					// Nueva función anónima: lambda_1
					// ln(2) + ln(2.718281828459) = 1.6931471805599
?>
	
		
	</body>
</html>

