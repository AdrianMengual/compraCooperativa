<?php 

session_start(); 
?>
<!DOCTYPE html>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script type="text/javascript" src="js/index.js"></script>
<link rel="stylesheet" href="style1.css">
</head>
<body>
    <?php 

	
	error_reporting(E_ERROR | E_WARNING | E_PARSE);
					//$con= mysql_connect("localhost", "root", "");
					$con = mysqli_connect("localhost", "root", "avergara334","CompraCooperativa");

					//$enlace = mysql_connect('localhost', 'root', '');
					if (!$con) {
						die('No se pudo conectar : ' . mysql_error());
					}
                    require("BD.php");

	               $result_productos = result_productos();

	               $productos = array();

	               while($row = $result_productos->fetch_assoc()) {
		           $productos[]= $row;
                    }
                    $validacio = 0;
                    $login = $_POST['login'];
                    $signup = $_POST['signup'];
                    if ( $login != NULL){
                        $nombre = $_POST['user'];
                        $pwd = $_POST['pass'];
                        $validacio = validacioUser($nombre,$pwd);
                        if ($validacio > 0){
						
                            session_start(); 
                            $_SESSION['user'] = $nombre; 
							$_SESSION['ID'] = $validacio; 
                        }
                        
                            
                        
                    }
                    if ( $signup != NULL){
                         echo "voy a registrarme";
                         $user = $_POST['user'];
                         $password = $_POST['password'];
                         $correo = $_POST['mail'];
                         $nif = $_POST['nif'];
                         creacionUser($user,$password,$correo,$nif);
                         
                        
   
                    }
    if(isset($_SESSION['ID'])){
               $validacio = $_SESSION['ID'];      
                   } 
                    
    ?>
<h2 class="text-left">sample center heading</h2>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Compra Cooperativa</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Inicio</a></li>
      <li><a href="index.php">Pagina 1</a></li>
      <li><a href="#">Pagina 2</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
     <?php
      if($validacio == 0){
      echo "<li><a href='#' data-toggle='modal' data-target='#signup-modal'><span class='glyphicon glyphicon-user'></span> Registrarse</a></li>";
      echo "<li><a href='#' data-toggle='modal' data-target='#login-modal'><span class='glyphicon glyphicon-log-in'></span> Iniciar Sesión</a></li>";
      }
      else{?>
      <li><a href='#'  onclick="ajaxget('view', 'user')"><span class='glyphicon glyphicon-user'></span> Sr.<?php echo $_SESSION['user'];?> </a></li>
      <li><a href='logout.php'><span class='glyphicon glyphicon-log-out'></span> Cerrar Sesión</a></li>
      <?php }
     ?>
    </ul>
  </div>
</nav>



<div class="container" id="ajax">
<!-- Header -->
        <!-- Header -->
    <header>
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">Welcome To Our Studio!</div>
                <div class="intro-heading">It's Nice To Meet You</div>
                <a href="#services" class="page-scroll btn btn-xl">Tell Me More</a>
            </div>
        </div>
    </header>

    <!-- Services Section -->
    <section id="services1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Services</h2>
                    <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">E-Commerce</h4>
                    <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Responsive Design</h4>
                    <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Web Security</h4>
                    <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
            </div>
        </div>
    </section>


 
  <div class="row">
       <?php
      foreach($productos as $productos){ 
    ?>
    <div class="col-sm-4" >
	<div class="thumbnail">
							<img src="Images/<?php echo $productos['imagen'];?>" alt="" width="300" height="200">
							<div class="caption">
								<h4><?php echo $productos['nombre'];?></h4>
								<div class="text-center rating" style="font-size:30px">
<span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
</div>
								<p><strike>Euro 150,00</strike>&nbsp;Euro <?php echo $productos['precio'];?></p>
								<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40"
  aria-valuemin="0" aria-valuemax="100" style="width:40%">
    40% completado (success)
  </div>                        
</div>
								<a class="btn btn-primary" href="#">Ver más</a>
								<a class="btn btn-success" href="#">Añdir al carrito</a>
							</div>
						</div>
      
    </div>
    <?php
      }              
    ?>
    </div>





<div  class="modal fade login " id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Inicia Sesión</h1><br>
				  <form method="post">
					<input type="text" name="user" placeholder="Nombre de Usario">
					<input type="password" name="pass" placeholder="Contraseña">
					<input type="submit" name="login" class="login loginmodal-submit" value="Inicio Sesión">
				  </form>
					
				  <div class="login-help">
					<a href="#"  data-toggle='modal' data-target='#signup-modal'>Registrarse</a> - <a href="#">Olvidaste Contraseña?</a>
				  </div>
				</div>
			</div>
</div>
<div  class="modal fade signup" id="signup-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Registro</h1><br>
				  <form method="post">
					<input type="text" name="user" placeholder="Nombre Empresa">
					<input type="password" name="password" placeholder="Contraseña">
                    <input type="text" name="mail" placeholder="Correo electronico">
					<input type="text" name="nif" placeholder="NIF empresa">
					<input type="submit" name="signup" class="login loginmodal-submit" value="Registrarse">
				  </form>
					
				  
				</div>
			</div>
    
</div>
    </div>    
</body>   
    
</html>