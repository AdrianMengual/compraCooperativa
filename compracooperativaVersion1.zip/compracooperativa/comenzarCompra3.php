<?php 

	function connectDB(){
		$servername = "localhost";
		$username = "root";
		$password = "avergara334"; //modificar por "avergara334" en el servidor del proyecto
		$dbname = "CompraCooperativa"; //modificar por "pruebalis" en el servidor del proyecto

		//Creamos la conexion
		$con = new mysqli($servername, $username, $password, $dbname);

			if ($conn->connect_error) {
                echo "hola";
				die("Conexion fallida: " . $con->connect_error);
			}
		$con ->set_charset("utf8");
		return $con;
 	}

 	function meterCompra($prod,$can,$est,$fec,$max,$pes)
    {

        $con = connectDB();
        $sql = "INSERT INTO `Compra` (`ID_Producto`,`Cantidad_Total`,`Estado`,`Fecha_Fin`,`Cantidad_Maxima`,`Peso`)
VALUES ('".$prod."','".$can."','".$est."','".$fec."','".$max."','".$pes."')";
        $result = $con->query($sql);
        return $result;


    }

    
?>