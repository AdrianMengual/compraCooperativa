<?php 
session_start();
error_reporting(E_ERROR | E_WARNING | E_PARSE);
	function connectDB(){
		$servername = "localhost";
		$username = "root";
		$password = "avergara334"; //modificar por "avergara334" en el servidor del proyecto
		$dbname = "CompraCooperativa"; //modificar por "pruebalis" en el servidor del proyecto

		//Creamos la conexion
		$con = new mysqli($servername, $username, $password, $dbname);

			if ($conn->connect_error) {
                echo "hola";
				die("Conexion fallida: " . $con->connect_error);
			}
		$con ->set_charset("utf8");
		return $con;
 	}

 	function result_productos(){
        $con = connectDB(); 
        $sql_productos = "SELECT ID_producto, ID_categoria, nombre, descripcion, tamano, stock, imagen, precio, MaxDias FROM `Productos`";
        $result_productos = $con->query($sql_productos);
        $hola= $result_productos->num_rows;
        return $result_productos;   
    }
    
     function result_producto_concreto($Id){
        $conn = connectDB(); 
        $sql_producto = "SELECT ID_producto, ID_categoria, nombre, descripcion, tamano, stock, imagen, precio, MaxDias FROM `Productos` where ID_producto=".$Id."";
        $result_producto = $conn->query($sql_producto);

        return $result_producto;
    }

    function result_producto_proveedor($Id){
        $conn = connectDB(); 
        $sql_producto_proveedor = "SELECT p.empresa FROM Proveedores p, Productos_proveedor pv, Productos pr WHERE pr.ID_producto = pv.ID_producto AND pv.ID_proveedor = p.ID_proveedor AND pr.ID_producto = ".$Id."";
        $result_producto_proveedor = $conn->query($sql_producto_proveedor);

        return $result_producto_proveedor;
    }
    
    function result_pedidos_user($Id){
        $conn = connectDB(); 
        $sql_pedidos_user = "SELECT pr.nombre, pe.cantidad, co.estado FROM Productos pr, Pedidos pe, Compra co WHERE pr.ID_producto = pe.ID_producto AND pr.ID_producto = co.ID_Producto AND pe.ID_Compra = co.ID_Compra AND pe.ID_user = ".$Id."";
        $result_pedidos_user = $conn->query($sql_pedidos_user);

        return $result_pedidos_user;
    }

    function result_compras(){
        $con = connectDB(); 
        $sql_compras = "SELECT ID_Compra, ID_Producto,Cantidad_Total, Estado, Fecha_Fin,Cantidad_Maxima, Peso FROM `Compra`";
        $result_compras = $con->query($sql_compras);

        return $result_compras;   
    }
    
    function result_provincias(){
        $con = connectDB(); 
        $sql_provincias = "SELECT Zona FROM `TarifasTransporteZonas`";
        $result_provincias = $con->query($sql_provincias);

        return $result_provincias;   
    }

    function validacioUser($nombre,$pwd){
         $con = connectDB(); 
         if ($nombre != NULL){
                        
					        $sql = "SELECT * FROM Usuarios WHERE user ='".$nombre."' AND password = '".$pwd."'";
                            $result = $con->query($sql);
                            $hola= $result->num_rows;
                            if($hola > 0){
								while($row = $result->fetch_array(MYSQLI_ASSOC)){
                                    $idu= $row["ID_user"];
                                }
                                return $idu;
                            }
                            else{
                                return 0;
                            }        
         }
    }

    function creacionUser($user,$password,$mail,$nif){
        $con = connectDB();
        $sql = "INSERT INTO `Usuarios` (`user`, `password`, `empresa`, `nombre_contacto`, `email`, `NIF`, `telefono`, `Datos_Banco`, `Direccion`, `Ciudad`, `CodigoPostal`) VALUES
('".$user."', '".$password."', '".$user."', ' ','".$mail."', '".$nif."', 123456, NULL, NULL, NULL, NULL)";
        $result = $con->query($sql);
        echo $sql;
        
    }

    function diasRestantes ($ID_Producto){
        $con = connectDB();
        $sql = "SELECT Fecha_Fin FROM `Compra`,`Productos` WHERE Compra.ID_Producto = '".$ID_Producto."'";
        $result = $con->query($sql);                           
        $hola= $result->num_rows;
        if($hola > 0){
				while($row = $result->fetch_array(MYSQLI_ASSOC)){
                            $idu= $row['Fecha_Fin'];
                        }
                $now = time(); // or your date as well
                $your_date = strtotime($idu);
                $datediff = $your_date - $now;
                return 100-(round(($datediff / (60 * 60 * 24))/0.3));
        }
        else{
            return 0;
        }
    } 

    function CrearCompra($valor,$id,$maxDias,$idv){
      $con = connectDB();
      $sqlid = "SELECT `ID_Compra` FROM `Compra`,`Productos` WHERE Productos.ID_Producto = '".$id."' AND Compra.ID_Producto = Productos.ID_producto";
       $idcompra = $con->query($sqlid);
         while($row = $idcompra->fetch_array(MYSQLI_ASSOC)){
                            $idc= $row["ID_Compra"];
         }                
       $hola= $idcompra->num_rows;
							
       if($hola > 0){
                                
            //return $idu;
           
           $v = 1;
           
                                
        }
        else{
            
            $v=0;
         }
      
      if ($v==1){
          
          $sql = "UPDATE `Compra` SET `Cantidad_Total`=`Cantidad_Total`+ '".$valor."' WHERE ID_Compra = '".$idc."'";
          
          $sql2 = "INSERT INTO `Pedidos` (`ID_user`, `ID_producto`, `cantidad`,`ID_Compra`) VALUES
('".$idv."', '".$id."', '".$valor."','".$idc."')";
          $result = $con->query($sql);
          $result2 = $con->query($sql2);
          
          
      }
      
     if ($v==0){
         $fecha= date_create();
         $add = "+ $maxDias day";
         date_modify($fecha, $add);
         $sql = "INSERT INTO `Compra` (`ID_Producto`, `Cantidad_Total`, `Estado`, `Fecha_Fin`, `Cantidad_Maxima`, `Peso`) VALUES
('".$id."', '".$valor."', 'Pend','".date_format($fecha, 'Y-m-d')."',500,50)";
         $result = $con->query($sql);
         $sqlid = "SELECT `ID_Compra` FROM `Compra`,`Productos` WHERE Productos.ID_Producto = '".$id."' AND Compra.ID_Producto = Productos.ID_producto";
        $idcompra = $con->query($sqlid);
         while($row = $idcompra->fetch_array(MYSQLI_ASSOC)){
                            $idc= $row["ID_Compra"];
         }      
          $sql2 = "INSERT INTO `Pedidos` (`ID_user`, `ID_producto`, `cantidad`,`ID_Compra`) VALUES
('".$idv."', '".$id."', '".$valor."','".$idc."')";
         $result2 = $con->query($sql2);
         
         
     }
      
      
    }

    function calculoPeso ($ID_Producto,$p,$v){
        $con = connectDB();
        
        $sql = "SELECT Peso FROM `Productos` WHERE ID_Producto = '".$ID_Producto."'";
        
        $result = $con->query($sql);
        $filapeso= $result->num_rows;
        if($filapeso > 0){
           while($row = $result->fetch_array(MYSQLI_ASSOC)){
               $peso= $row['Peso'];
               $peso = $peso * $v;
           }
               
        }
        else{
            return 0;
        }
        
        $prov = "Select Cod_Zona,Zona from `TarifasTransporteZonas` where Zona = '".$p."'";
        $result = $con->query($prov);
        $filazona= $result->num_rows;
        if($filazona > 0){
           while($row = $result->fetch_array(MYSQLI_ASSOC)){
               $provincia= $row['Cod_Zona'];
               $nombreprovincia = $row['Zona'];
               
           }
               
        }
        else {
            echo "Nooo";
        }
       $precio = "Select MIN(Euros) as minimum from `TarifasTransporte` where Kg >= '".$peso."' AND Cod_Zona = '".$provincia."'";
        $resultado = $con->query($precio);
        $filaprecio= $resultado->num_rows;
        if($filaprecio > 0){
           while($row = $resultado->fetch_array(MYSQLI_ASSOC)){
               $precioenvio = $row['minimum'];
               
           }
               
        }
        
        else {
            echo "Nor";
        }
        echo "el envio a: ";
        echo $nombreprovincia;
        echo "\n";
        echo "te costará: ";
        echo $precioenvio;
        echo "€";
    } 

?>