<?php
require_once("comenzarCompra3.php");
$prod =  $_POST['Producto'];
$can = $_POST['cantidad']; 
$est =  $_POST['estado'];
$fec =  $_POST['fecha'];
$max =$_POST['maxima'];
$pes =$_POST['peso'];


meterCompra($prod,$can,$est,$fec,$max,$pes);

            
          


?>