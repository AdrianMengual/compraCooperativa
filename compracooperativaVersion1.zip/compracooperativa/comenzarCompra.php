<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Agregar compra</title>
</head>

<body>

    <center><h1>Agregar una nueva compra</h1></center>
    <form action="comenzarCompra2.php" method = "post" enctype="multipart/form-data">
        <fieldset> 
            ID_Producto<br>
            <input type="text" name="Producto">
        </fieldset>
        <fieldset>
           Cantidad<br>
           <input type="text" name="cantidad" >  </textarea>
        </fieldset>
        <fieldset>
            Estado<br>
            <input type="text" name="estado">
        </fieldset>
        <fieldset>
            fecha<br>
            <input type="text" name="fecha">
        </fieldset>
        <fieldset>
            Cantidad Maxima<br>
            <input type="text" name="maxima">

        </fieldset>
             <fieldset>
            Peso<br>
            <input type="text" name="peso">

        </fieldset>
        <input type="submit" name="accion" value="Enviar">
        

    </form>
</body>
</html>