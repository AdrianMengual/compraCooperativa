<?php 

	function connectDB(){
		$servername = "localhost";
		$username = "root";
		$password = "avergara334"; //modificar por "avergara334" en el servidor del proyecto
		$dbname = "CompraCooperativa"; //modificar por "pruebalis" en el servidor del proyecto

		//Creamos la conexion
		$con = new mysqli($servername, $username, $password, $dbname);

			if ($conn->connect_error) {
                echo "hola";
				die("Conexion fallida: " . $con->connect_error);
			}
		$con ->set_charset("utf8");
		return $con;
 	}

 	function result_productos(){
        $con = connectDB(); 
        $sql_productos = "SELECT ID_producto, ID_categoria, nombre, descripcion, tamano, stock, imagen, precio FROM `Productos`";
        $result_productos = $con->query($sql_productos);

        return $result_productos;   
    }
    function validacioUser($nombre,$pwd){
         $con = connectDB(); 
         if ($nombre != NULL){
                        
					        $sql = "SELECT * FROM Usuarios WHERE user ='".$nombre."' AND password = '".$pwd."'";
                            $result = $con->query($sql);
                           
                            $hola= $result->num_rows;
                            if($hola > 0){
                                
                                return 1;
                                
                            }
                            else{
                                return 0;
                            }
                           
                        
         }
    }

    function creacionUser($user,$password,$mail,$nif){
        $con = connectDB();
        
        $sql = "INSERT INTO `Usuarios` (`user`, `password`, `empresa`, `nombre_contacto`, `email`, `NIF`, `telefono`, `Datos_Banco`, `Direccion`, `Ciudad`, `CodigoPostal`) VALUES
('".$user."', '".$password."', 'EmpresaAlbert', 'Albert Mengod', '".$mail."', '".$nif."', 123456, NULL, NULL, NULL, NULL)";
        $result = $con->query($sql);
        
    }
?>