<?php
    session_start();
    include("../BD.php");
    $id = $_GET['id'];

    $result_producto_concreto = result_producto_concreto($id); 
    $result_producto_proveedor = result_producto_proveedor($id);
    $result_compras = result_compras();
    $compras = array();

    while($col = $result_compras->fetch_assoc()) {
        $compras[]= $col;
    }
    foreach ($compras as $compras){
        if($id == $compras['ID_Producto']){
            $Cantidad_Total = $compras['Cantidad_Total'] ;
            $Cantidad_Maxima = $compras['Cantidad_Maxima'] ;
            $valor = round($Cantidad_Total/$Cantidad_Maxima*100);
            $dias = DiasRestantes($id);
            break;
        }
    }
    while($obj = $result_producto_concreto->fetch_object()){
        $dato = $obj;
    }

    while($obj = $result_producto_proveedor->fetch_object()){
        $empresa = $obj;
    }
    $nombre = $dato->nombre;
    $descripcion =  $dato->descripcion;
    $stock = $dato->stock;
    $precio = $dato->precio;
    $imagen = $dato->imagen;
    $tamaño = $dato->tamano;
    $proveedor = $empresa->empresa;
    $maxDias = $dato->MaxDias;
    

?>


    <script src="js/functions.js"></script>
 

	<div class="row">
   <div class="col-xs-4 item-photo">
                    <img style="max-width:100%;" src="Images/<?php echo $imagen;?>">
                </div>
                <div class="col-xs-8" style="border:0px solid gray">
                    <!-- Datos del vendedor y titulo del producto -->
                    <h3><?php echo $nombre;?></h3>    
                    <h5 style="color:#337ab7">vendido por <a href="#"><?php echo $proveedor;?></a> · <small style="color:#337ab7">(5054 ventas)</small></h5>

                    <!-- Precios -->
                    <h6 class="title-price"><small>OFERTA PRECIO</small></h6>
                    <h3 style="margin-top:0px;"><?php echo $precio; ?> €</h3>

                    <!-- Detalles especificos del producto -->
					<div class="section" style="padding-bottom:5px;">
                        <h6 class="title-attr"><small>Compra mínima</small></h6>                    
                        
                            <h5>50 unidades</h5>
                            
                        
                    </div> 
					<div class="section" style="padding-bottom:5px;">
															<div class="progress">
  <div class="progress-bar progress-bar-<?php 
          if ($valor <= 25) {
    echo "success";
} elseif ($valor <= 50) {
    echo "info";
} elseif ($valor <= 75) {
    echo "warning";
}
  else {
    echo "danger";
} ?>
              " role="progressbar" aria-valuenow="<?php echo $valor;?>"
  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $valor;?>%">
    <?php echo $valor;?>%
  </div>                        
</div>	
                            
                        
                    </div>
                    <div class="section" style="padding-bottom:5px;">
                        <h6 class="title-attr"><small>Periodo transcurrido de Compra</small></h6>                    
                        
                            
                        
                    </div>                

					<div class="section" style="padding-bottom:5px;">
															<div class="progress">
  <div class="progress-bar progress-bar-<?php 
          if ($dias <= 25) {
    echo "success";
} elseif ($dias <= 50) {
    echo "info";
} elseif ($dias <= 75) {
    echo "warning";
}
  else {
    echo "danger";
} ?>
              " role="progressbar" aria-valuenow="<?php echo $dias;?>"
  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $dias;?>%">
    <?php echo $dias;?>%
  </div>                        
</div>	
                            
                        
                    </div>
                    <!--<div class="section">
                        <h6 class="title-attr" style="margin-top:15px;" ><small>COLOR</small></h6>                    
                        <div>
                            <div class="attr" style="width:25px;background:#5a5a5a;"></div>
                            <div class="attr" style="width:25px;background:white;"></div>
                        </div>
                    </div>
                    <div class="section" style="padding-bottom:5px;">
                        <h6 class="title-attr"><small>CAPACIDAD</small></h6>                    
                        <div>
                            <div class="attr2">16 GB</div>
                            <div class="attr2">32 GB</div>
                        </div>
                    </div>  
-->					
                    <div class="section" style="padding-bottom:5px;">
                        <h6 class="title-attr"><small>CANTIDAD</small></h6>                    
                        <div>
                            
                            <form  method="post">
                            <div>
                            <div class="btn-minus"><span class="glyphicon glyphicon-minus"></span></div>
                            <input name="valor" value="150" />
                            <div class="btn-plus"><span class="glyphicon glyphicon-plus"></span></div>
                            </div>
                            <input type=hidden name="id" value="<?php echo $id; ?>" />
                            <input type=hidden name="maxDias" value="<?php echo $maxDias; ?>" />
                            <!--<button type="submit" class="btn btn-success"><span style="margin-right:20px" class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> Agregar al carro</button>-->
                            
                            </form>
                        </div>
                    </div>  
					<div class="section" style="padding-bottom:5px;">
                        <h6 class="title-attr"><small>Precio Total</small></h6>                    
                        
                            <h5>XX,Y € </h5>
                            
                        
                    </div> 

                    <!-- Botones de compra -->
                    <div class="section" style="padding-bottom:20px;">
                       <!-- <button class="btn btn-success"><span style="margin-right:20px" class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></span> Agregar al carro</button>-->
                        
                    </div>                                        
                </div>   
		

                <div class="col-xs-12">
				<!--div id="container1" style="min-width: 310px; height: 400px; margin: 0 auto">Gráfico</div-->		
				
                    <ul class="menu-items">
                        <li class="active">Detalle del producto</li>
                        <li>Garantía</li>
                        <li>Vendedor</li>
                        <li>Envío</li>
                    </ul>
                    <div style="width:100%;border-top:1px solid silver">
                        <p style="padding:15px;">
                           <?php echo $descripcion;?>
                        </p>
                        
                    </div>
                </div>		
	</div>


