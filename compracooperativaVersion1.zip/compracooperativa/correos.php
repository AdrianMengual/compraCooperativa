<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <?php 
		// compracooperativa@gmail.com
		// compracooperativa123

		function smtpmailer($to, $from, $from_name, $subject, $body) { 
			require_once('phpmailer/class.phpmailer.php');
			include('phpmailer/class.smtp.php');
			global $error;
			$mail = new PHPMailer();  // create a new object
			$mail->IsSMTP(); // enable SMTP
			$mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
			$mail->SMTPAuth = true;  // authentication enabled
			$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for GMail
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 587; 
			$mail->Username = "compracooperativa@gmail.com";  
			$mail->Password = "compracooperativa123";           
			$mail->SetFrom($from, $from_name);
			$mail->Subject = $subject;
			$mail->Body = $body;
			$mail->AddAddress($to);
			if(!$mail->Send()) {
				$error = 'Mail error: '.$mail->ErrorInfo; 
				return false;
			} else {
				$error = 'Message sent!';
				return true;
			}
		}
		
		//function mail() { 
			if (smtpmailer('compracooperativa@gmail.com', 'compracooperativa@gmail.com', 'Prueba', 'test mail message', 'Hello World!')) {
				// do something
				echo "Funciona!!";
			}
			if (!empty($error)) echo $error;
		//}
		
	?>
	
	<!--<input type="submit" name="email" class="login loginmodal-submit" value="Email" onclick="<? echo"mail()"; ?>">-->
</body>

   
</html>
