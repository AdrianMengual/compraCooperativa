<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/index.js"></script>
  <script type="text/javascript" src="http://code.highcharts.com/highcharts.js"></script>
  <script src="js/index.js"></script>
  <script src="js/functions.js"></script>
  <link rel="stylesheet" href="style1.css">
</head>
<body>
    <?php 
	error_reporting(E_ERROR | E_WARNING | E_PARSE);
					//$con= mysql_connect("localhost", "root", "");
					$con = mysqli_connect("localhost", "root", "avergara334","CompraCooperativa");

					//$enlace = mysql_connect('localhost', 'root', '');
					if (!$con) {
						die('No se pudo conectar : ' . mysql_error());
					}
                session_start();
                include("BD.php");
                $validacio = 0;
                $validacio = $_SESSION['IDv'];
                
	            $result_productos = result_productos();
                $result_compras = result_compras();
	            $productos = array();
                $compras = array();

	            while($row = $result_productos->fetch_assoc()) {
		                $productos[]= $row;
                }
                while($col = $result_compras->fetch_assoc()) {
                    $compras[]= $col;
                }

                    
                    $login = $_POST['login'];
                    $signup = $_POST['signup'];
                    if ( $login != NULL){
                        $login = NULL;
                        $nombre = $_POST['user'];
                        $pwd = $_POST['pass'];
                        $validacio = validacioUser($nombre,$pwd);
                        if ($validacio > 0){
                            $_SESSION['user'] = $nombre; 
				            $_SESSION['IDv'] = $validacio; 
                        }     
                    }
                    if ( $signup != NULL){
                         echo "voy a registrarme";
                         $user = $_POST['user'];
                         $password = $_POST['password'];
                         $correo = $_POST['mail'];
                         $nif = $_POST['nif'];
                         creacionUser($user,$password,$correo,$nif);
                    }            
    ?>
<h2 class="text-left">sample center heading</h2>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="indextest2.php">Compra Cooperativa</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">Page 1</a></li>
      <li><a href="#"><?php echo $_SESSION['IDv'];?></a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
     <?php
      if($validacio == 0){
      echo "<li><a href='#' data-toggle='modal' data-target='#signup-modal'><span class='glyphicon glyphicon-user'></span> Registrarse</a></li>";
      echo "<li><a href='#' data-toggle='modal' data-target='#login-modal'><span class='glyphicon glyphicon-log-in'></span> Iniciar Sesion</a></li>";
      }
      else{?>
      <li><a href='#'  onclick="ajaxget('view', 'user')"><span class='glyphicon glyphicon-user'></span> Sr.<?php echo $_SESSION['user'];?> </a></li>
      <li><a href='logout.php'><span class='glyphicon glyphicon-log-out'></span> Cerrar Sesion</a></li>
      <?php }
     ?>
    </ul>
  </div>
</nav>



<div class="container" id="ajax">
<!-- Header -->
        <!-- Header -->
    <header>
        <div class="container">
            <!--div class="intro-text"-->
            <div>
                <div class="intro-lead-in">Welcome To Our Studio!</div>
                <div class="intro-heading">Its Nice To Meet You</div>
                <a href="#services" class="page-scroll btn btn-xl">Tell Me More</a>
            </div>
        </div>
    </header>

    <!-- Services Section -->
    <section id="services1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Services</h2>
                    <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">E-Commerce</h4>
                    <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Responsive Design</h4>
                    <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Web Security</h4>
                    <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
                </div>
            </div>
        </div>
    </section>


 
  <div class="row">
    <?php
      $valor = $_POST['valor'];
      $IDCompra = $_POST['id'];
      $MaxDias = $_POST['maxDias'];
      if ($valor != null){
        CrearCompra($valor,$IDCompra,$MaxDias,$_SESSION['IDv']);
      }

      foreach($productos as $productos){ 
    ?>
  <div class="col-sm-4" >
	<div class="thumbnail">
			<img src="Images/<?php echo $productos['imagen'];?>" alt="" width="300" height="200">
			<div class="caption">
				<h4><?php echo $productos['nombre'];?></h4>
				<div class="text-center rating" style="font-size:30px">
          <span>☆</span><span>☆</span><span>☆</span><span>☆</span><span>☆</span>
        </div>
  <?php
                                
    foreach ($compras as $compra){
                                   
      if($compra['ID_Producto']==$productos['ID_producto']){
          $valor = round($compra['Cantidad_Total']/$compra['Cantidad_Maxima']*100);
          $dias = DiasRestantes($compra['ID_Producto']);
          break;
      }
      else{
          $valor = 0;
      }
    }
  ?>

  <div class="progress">
  <div class="progress-bar progress-bar-<?php 
                                if ($valor <= 25) {
                                    echo "success";
                                } elseif ($valor <= 50) {
                                    echo "info";
                                } elseif ($valor <= 75) {
                                    echo "warning";
                                }else {
                                    echo "danger";
                                } 
                                ?>" role="progressbar" aria-valuenow="<?php echo $valor;?>"
  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $valor;?>%">
  <?php if($valor < 0){
          echo "0";
        }else if($valor > 100){
          echo "100";
        }
        else {
          echo $valor;
        }
  ?>%
  </div>                        
  </div>
    <!-- <ul class="nav navbar-nav navbar-right">
     <?php
      if($validacio == 0){
          echo "<li><a class='btn btn-primary' onclick='getParamId('view', 'detailsprodtest2')'>Ver más</a></li>";
      }
      else{?>
      <li><a class="btn btn-primary" onclick="getParamId('view', 'detailsprodtest2', <?php echo $productos['ID_producto'];?>)">Ver más</a></li>
      <li><a class="btn btn-success" href="#">Add to Cart</a></li>
      <?php }
     ?>
    </ul> -->
		 <a class="btn btn-primary" onclick="getParamId('view', 'detailsprodtest2', <?php echo $productos['ID_producto'];?>)">Ver más</a>
		<a class="btn btn-success" href="#">Add to Cart</a> 
	</div>
	</div>
      
  </div>
    <?php
      }              
    ?>
  </div>





<div  class="modal fade login " id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Inicia Sesión</h1><br>
				  <form method="post">
					<input type="text" name="user" placeholder="Username">
					<input type="password" name="pass" placeholder="Password">
					<input type="submit" name="login" class="login loginmodal-submit" value="Login">
				  </form>
					
				  <div class="login-help">
					<a href="#"  data-toggle='modal' data-target='#signup-modal'>Register</a> - <a href="#">Forgot Password</a>
				  </div>
				</div>
			</div>
</div>
<div  class="modal fade signup" id="signup-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Registro</h1><br>
				  <form method="post">
					<input type="text" name="user" placeholder="Nombre Empresa">
					<input type="password" name="password" placeholder="Contraseña">
                    <input type="text" name="mail" placeholder="Correo electronico">
					<input type="text" name="nif" placeholder="NIF empresa">
					<input type="submit" name="signup" class="login loginmodal-submit" value="SignUp">
				  </form>
				</div>
			</div>  
</div>
</div>    
</body>     
</html>